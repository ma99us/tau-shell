# MVP Backlog

Must Have:
- ConPTY host
- Session registry
- Restore engine
- Mobile dashboard
- Notifications

Future:
- Voice notifications
- Distributed execution
- Cloud sync

# PowerShell Bootstrap

Default settings:
- UTF-8
- chcp 65001
- PSReadLine
- Tool aliases
- Session metadata variables

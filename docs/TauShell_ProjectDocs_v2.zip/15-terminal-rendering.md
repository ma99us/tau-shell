# Terminal Rendering

Goals:
- Unicode support
- Nerd Font support
- Emoji support
- Colour preservation
- Mobile-friendly rendering
